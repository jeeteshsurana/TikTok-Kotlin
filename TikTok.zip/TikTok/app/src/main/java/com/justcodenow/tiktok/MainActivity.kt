package com.justcodenow.tiktok

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity(), View.OnClickListener {


    private var lastActivatePlayer = ""
    private var totalActivateButton = 0
    private var arrayList = ArrayList<TikTokModel>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        init()
    }

    private fun init() {
        initArrayList()
        btn_0.setOnClickListener(this)
        btn_1.setOnClickListener(this)
        btn_2.setOnClickListener(this)
        btn_3.setOnClickListener(this)
        btn_4.setOnClickListener(this)
        btn_5.setOnClickListener(this)
        btn_6.setOnClickListener(this)
        btn_7.setOnClickListener(this)
        btn_8.setOnClickListener(this)

    }

    private fun initArrayList() {
        for (i in 0 until 9) {
            arrayList.add(TikTokModel(""))
        }
    }

    override fun onClick(v: View?) {
        when (v!!.id) {
            R.id.btn_0 -> {
                buttonEntry(btn_0, 0)
            }
            R.id.btn_1 -> {
                buttonEntry(btn_1, 1)
            }
            R.id.btn_2 -> {
                buttonEntry(btn_2, 2)
            }
            R.id.btn_3 -> {
                buttonEntry(btn_3, 3)
            }
            R.id.btn_4 -> {
                buttonEntry(btn_4, 4)
            }
            R.id.btn_5 -> {
                buttonEntry(btn_5, 5)
            }
            R.id.btn_6 -> {
                buttonEntry(btn_6, 6)
            }
            R.id.btn_7 -> {
                buttonEntry(btn_7, 7)
            }
            R.id.btn_8 -> {
                buttonEntry(btn_8, 8)
            }
        }
    }

    private fun buttonEntry(button: Button, pos: Int) {
        if (button.text.isEmpty()) {
            button.text = checkLastPlayer(pos)
            totalActivateButton++
            if (totalActivateButton >= 5) {
                checkWinner()
            }
        } else
            return
    }

    private fun checkLastPlayer(pos: Int): String {

        return when {
            lastActivatePlayer.isEmpty() -> {
                lastActivatePlayer = "O"
                arrayList[pos] = TikTokModel("O")
                "O"
            }
            lastActivatePlayer.equals("O", true) -> {
                lastActivatePlayer = "X"
                arrayList[pos] = TikTokModel("X")
                "X"
            }
            lastActivatePlayer.equals("X", true) -> {
                lastActivatePlayer = "O"
                arrayList[pos] = TikTokModel("O")
                "O"
            }
            else -> {
                "O"
            }
        }
    }

    private fun checkWinner() {

        if (testing("X")) {
            Toast.makeText(this, "X is win", Toast.LENGTH_SHORT).show()
            resetAll()
        } else if (testing("O")) {
            Toast.makeText(this, "O is win", Toast.LENGTH_SHORT).show()
            resetAll()
        }

        if (totalActivateButton >= 9) {
            Toast.makeText(this, "match draw ", Toast.LENGTH_SHORT).show()
            resetAll()
        }
    }

    private fun resetAll() {
        arrayList.clear()
        btn_0.text = ""
        btn_1.text = ""
        btn_2.text = ""
        btn_3.text = ""
        btn_4.text = ""
        btn_5.text = ""
        btn_6.text = ""
        btn_7.text = ""
        btn_8.text = ""
        initArrayList()
        lastActivatePlayer = ""
        totalActivateButton = 0
    }


    private fun testing(player: String): Boolean {
        return when {
            arrayList[0].Value.equals(player) && arrayList[1].Value.equals(player) && arrayList[2].Value.equals(player) -> true
            arrayList[3].Value.equals(player) && arrayList[4].Value.equals(player) && arrayList[5].Value.equals(player) -> true
            arrayList[6].Value.equals(player) && arrayList[7].Value.equals(player) && arrayList[8].Value.equals(player) -> true
            arrayList[0].Value.equals(player) && arrayList[3].Value.equals(player) && arrayList[6].Value.equals(player) -> true
            arrayList[1].Value.equals(player) && arrayList[4].Value.equals(player) && arrayList[7].Value.equals(player) -> true
            arrayList[2].Value.equals(player) && arrayList[5].Value.equals(player) && arrayList[8].Value.equals(player) -> true
            arrayList[0].Value.equals(player) && arrayList[4].Value.equals(player) && arrayList[8].Value.equals(player) -> true
            arrayList[2].Value.equals(player) && arrayList[4].Value.equals(player) && arrayList[6].Value.equals(player) -> true
            else ->
                false
        }
    }
}
