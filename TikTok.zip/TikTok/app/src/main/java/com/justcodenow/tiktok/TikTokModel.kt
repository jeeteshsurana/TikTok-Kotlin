package com.justcodenow.tiktok

data class TikTokModel(var Value: String? = null)